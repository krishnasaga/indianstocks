#!/usr/bin/env bash
zip -r lambda.zip *
aws lambda update-function-code \
    --function-name  my-function \
    --zip-file fileb://lambda.zip
