const { Service } = require('feathers-sequelize');

exports.Sectors = class Sectors extends Service {
  
};
